importScripts('https://cdn.jsdelivr.net/npm/jsqr@1.2.0/dist/jsQR.min.js');self.func = ({
    data,
    width,
    height
  }) => {
    // eslint-disable-next-line no-undef
    const decoded = self.jsQR(data, width, height, {
      inversionAttempts: 'attemptBoth'
    });
    let parsed;
    try {
      parsed = JSON.parse(decoded);
    } catch {
      parsed = decoded;
    }
    if (parsed?.data) {
      const nativeEvent = {
        type: 'qr',
        data: parsed.data,
        cornerPoints: [],
        bounds: {
          origin: {
            x: 0,
            y: 0
          },
          size: {
            width: 0,
            height: 0
          }
        }
      };
      if (parsed.location) {
        nativeEvent.cornerPoints = [parsed.location.topLeftCorner, parsed.location.bottomLeftCorner, parsed.location.topRightCorner, parsed.location.bottomRightCorner];
      }
      return nativeEvent;
    }
    return parsed;
  };self.onmessage = (e) => {  const result = self.func(e.data);  self.postMessage(result);};